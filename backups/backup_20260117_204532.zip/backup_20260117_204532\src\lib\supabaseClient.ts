import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://botdcjmwfrzakgvwhhpx.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJvdGRjam13ZnJ6YWtndndoaHB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE0MTU5OTUsImV4cCI6MjA3Njk5MTk5NX0.EtbGwLO0-YwXyqYZCfJNz3jw5lbLGZO6RbgfYGn0Zvo';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Table names
export const TABLES = {
  TASKS: 'app_f226d1f8f5_tasks',
  PROJECTS: 'app_f226d1f8f5_projects',
  EMPLOYEES: 'app_f226d1f8f5_employees',
  CELEBRITIES: 'app_f226d1f8f5_celebrities',
  TRANSACTIONS: 'app_f226d1f8f5_transactions',
  DONATIONS: 'app_f226d1f8f5_donations',
  ROLES: 'app_f226d1f8f5_roles',
  ADMIN_USERS: 'app_f226d1f8f5_admin_users',
  TRAINING_MATERIALS: 'app_f226d1f8f5_training_materials',
  DONORS: 'app_f226d1f8f5_donors',
  CAMPAIGNS: 'app_f226d1f8f5_campaigns',
  TEAMS: 'app_f226d1f8f5_teams',
  SETTINGS: 'app_f226d1f8f5_settings',
  SUCCESS_STORIES: 'app_f226d1f8f5_success_stories',
  ACHIEVEMENTS: 'app_f226d1f8f5_achievements',
  USER_ACHIEVEMENTS: 'app_f226d1f8f5_user_achievements',
  GAMIFICATION_PROFILES: 'app_f226d1f8f5_gamification_profiles',
  CHALLENGES: 'app_f226d1f8f5_challenges',
  REWARDS: 'app_f226d1f8f5_rewards',
  BEST_PRACTICES: 'app_f226d1f8f5_best_practices',
  TARGETS: 'app_f226d1f8f5_targets'
};

// Types for roles and admin users
export interface Role {
  id: string;
  name: string;
  description: string | null;
  permissions: string[];
  color: string;
  created_at: string;
  updated_at: string;
}

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  role_id: string | null;
  status: 'active' | 'inactive' | 'suspended';
  last_login: string | null;
  created_at: string;
  updated_at: string;
}

// Types for transactions
export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  project?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Donor {
  id: string;
  name: string;
  email: string;
  phone: string;
  type: 'individual' | 'organization';
  segment: 'vip' | 'regular' | 'new';
  total_donations: number;
  donations_count: number;
  last_donation_date?: string;
  status: 'active' | 'inactive';
  notes?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Donation {
  id: string;
  donor_id: string;
  amount: number;
  date: string;
  cause?: string;
  method?: 'bank_transfer' | 'credit_card' | 'cash' | string;
  project_id?: string;
  created_at?: string;
}

export interface Campaign {
  id: string;
  name: string;
  platform: 'snapchat' | 'tiktok' | 'instagram' | 'google' | 'whatsapp' | 'other';
  spend: number;
  revenue: number;
  impressions: number;
  clicks: number;
  conversions: number;
  new_donors: number;
  status: 'active' | 'completed' | 'paused';
  start_date: string;
  end_date?: string;
  celebrity_id?: string | null;
  created_at?: string;
}

// Types for celebrities
export interface Celebrity {
  id: string;
  name: string;
  type: string;
  platform: string;
  followers: number;
  engagement_rate: number;
  contact: string;
  status: 'active' | 'inactive';
  notes?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Task {
  id: string | number;
  title: string;
  description?: string;
  status: 'pending' | 'in_progress' | 'completed' | string;
  priority?: 'low' | 'medium' | 'high' | string;
  assigned_to?: string | number | null;
  project?: string | null;
  due_date?: string | null;
  revenue?: number | null;
  progress?: number | null;
  notes?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface Target {
  id: string;
  name: string;
  type: 'employee' | 'project';
  period: 'weekly' | 'monthly' | 'annual';
  revenue_target: number;
  current_revenue: number;
  expenses_budget?: number;
  current_expenses?: number;
  roi?: number;
  roi_formula?: string;
  progress: number;
  start_date?: string;
  end_date?: string;
  created_at?: string;
  updated_at?: string;
}

// Basic API functions
export const supabaseAPI = {
  async getTasks() {
    try {
      const { data, error } = await supabase
        .from(TABLES.TASKS)
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching tasks:', error);
      return [];
    }
  },

  async getTaskById(id: string | number) {
    try {
      const { data, error } = await supabase
        .from(TABLES.TASKS)
        .select('*')
        .eq('id', id)
        .maybeSingle();
      
      if (error) throw error;
      return data || null;
    } catch (error) {
      console.error('Error fetching task by id:', error);
      return null;
    }
  },

  async getEmployees() {
    try {
      const { data, error } = await supabase
        .from(TABLES.EMPLOYEES)
        .select('*')
        .order('name', { ascending: true });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching employees:', error);
      return [];
    }
  },

  async getTeams() {
    try {
      const { data, error } = await supabase
        .from(TABLES.TEAMS)
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching teams:', error);
      return [];
    }
  },

  async getTrainingMaterials() {
    try {
      const { data, error } = await supabase
        .from(TABLES.TRAINING_MATERIALS)
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching training materials:', error);
      return [];
    }
  },

  async getDonors() {
    try {
      const { data, error } = await supabase
        .from(TABLES.DONORS)
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching donors:', error);
      return [];
    }
  },

  async getDonorById(id: string) {
    try {
      const { data, error } = await supabase
        .from(TABLES.DONORS)
        .select('*')
        .eq('id', id)
        .maybeSingle();
      
      if (error) throw error;
      return data || null;
    } catch (error) {
      console.error('Error fetching donor:', error);
      return null;
    }
  },

  async getDonationsByDonor(donorId: string) {
    try {
      const { data, error } = await supabase
        .from(TABLES.DONATIONS)
        .select('*')
        .eq('donor_id', donorId)
        .order('date', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching donations:', error);
      return [];
    }
  },

  async createDonor(donorData: Omit<Donor, 'id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.DONORS)
        .insert([{ 
          ...donorData, 
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating donor:', error);
      throw error;
    }
  },

  async updateDonor(id: string, updates: Partial<Donor>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.DONORS)
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error updating donor:', error);
      throw error;
    }
  },

  async createDonation(donationData: Omit<Donation, 'id' | 'created_at'>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.DONATIONS)
        .insert([{ ...donationData, date: donationData.date || new Date().toISOString() }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating donation:', error);
      throw error;
    }
  },

  async deleteDonor(id: string) {
    try {
      const { error } = await supabase
        .from(TABLES.DONORS)
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    } catch (error) {
      console.error('Error deleting donor:', error);
      throw error;
    }
  },

  async getCampaigns() {
    try {
      const { data, error } = await supabase
        .from(TABLES.CAMPAIGNS)
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching campaigns:', error);
      return [];
    }
  },

  async getCampaignsByCelebrity(celebrityId: string) {
    try {
      const { data, error } = await supabase
        .from(TABLES.CAMPAIGNS)
        .select('*')
        .eq('celebrity_id', celebrityId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching campaigns by celebrity:', error);
      return [];
    }
  },

  async getProjects() {
    try {
      const { data, error } = await supabase
        .from(TABLES.PROJECTS)
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching projects:', error);
      return [];
    }
  },

  async getTargets() {
    try {
      const { data, error } = await supabase
        .from(TABLES.TARGETS)
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching targets:', error);
      return [];
    }
  },

  async createTarget(targetData: Omit<Target, 'id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.TARGETS)
        .insert([{ 
          ...targetData, 
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating target:', error);
      throw error;
    }
  },

  async updateTarget(id: string, updates: Partial<Target>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.TARGETS)
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error updating target:', error);
      throw error;
    }
  },

  async deleteTarget(id: string) {
    try {
      const { error } = await supabase
        .from(TABLES.TARGETS)
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    } catch (error) {
      console.error('Error deleting target:', error);
      throw error;
    }
  },

  async getCelebrities() {
    try {
      const { data, error } = await supabase
        .from(TABLES.CELEBRITIES)
        .select('*')
        .order('name', { ascending: true });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching celebrities:', error);
      return [];
    }
  },

  async getCelebrityById(id: string) {
    try {
      const { data, error } = await supabase
        .from(TABLES.CELEBRITIES)
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (error) throw error;
      return data || null;
    } catch (error) {
      console.error('Error fetching celebrity by id:', error);
      return null;
    }
  },

  async getTransactions() {
    try {
      const { data, error } = await supabase
        .from(TABLES.TRANSACTIONS)
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching transactions:', error);
      return [];
    }
  },

  async getAdminUsers() {
    try {
      const { data, error } = await supabase
        .from(TABLES.ADMIN_USERS)
        .select('*')
        .order('name', { ascending: true });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching admin users:', error);
      return [];
    }
  },

  async getRoles() {
    try {
      const { data, error } = await supabase
        .from(TABLES.ROLES)
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching roles:', error);
      return [];
    }
  },

  async createRole(roleData: Omit<Role, 'id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.ROLES)
        .insert([{ 
          ...roleData, 
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating role:', error);
      throw error;
    }
  },

  async createAdminUser(userData: Omit<AdminUser, 'id' | 'created_at' | 'updated_at' | 'last_login'>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.ADMIN_USERS)
        .insert([{ 
          ...userData, 
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating admin user:', error);
      throw error;
    }
  },

  async createTask(task) {
    const { data, error } = await supabase
      .from(TABLES.TASKS)
      .insert([{ ...task, updated_at: new Date().toISOString() }])
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async updateTask(id, updates) {
    const { data, error } = await supabase
      .from(TABLES.TASKS)
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async deleteTask(id) {
    const { error } = await supabase
      .from(TABLES.TASKS)
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  // Project methods
  async createProject(projectData) {
    const { data, error } = await supabase
      .from(TABLES.PROJECTS)
      .insert([{ ...projectData, updated_at: new Date().toISOString() }])
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async updateProject(id, updates) {
    const { data, error } = await supabase
      .from(TABLES.PROJECTS)
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async deleteProject(id) {
    const { error } = await supabase
      .from(TABLES.PROJECTS)
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  // Transaction methods
  async createTransaction(transactionData: Omit<Transaction, 'id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.TRANSACTIONS)
        .insert([{ 
          ...transactionData, 
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating transaction:', error);
      throw error;
    }
  },

  async updateTransaction(id: string, updates: Partial<Transaction>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.TRANSACTIONS)
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error updating transaction:', error);
      throw error;
    }
  },

  async deleteTransaction(id: string) {
    try {
      const { error } = await supabase
        .from(TABLES.TRANSACTIONS)
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    } catch (error) {
      console.error('Error deleting transaction:', error);
      throw error;
    }
  },

  // Celebrity methods
  async createCelebrity(celebrityData: Omit<Celebrity, 'id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.CELEBRITIES)
        .insert([{ 
          ...celebrityData, 
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating celebrity:', error);
      throw error;
    }
  },

  async updateCelebrity(id: string, updates: Partial<Celebrity>) {
    try {
      const { data, error } = await supabase
        .from(TABLES.CELEBRITIES)
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error updating celebrity:', error);
      throw error;
    }
  },

  async deleteCelebrity(id: string) {
    try {
      const { error } = await supabase
        .from(TABLES.CELEBRITIES)
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    } catch (error) {
      console.error('Error deleting celebrity:', error);
      throw error;
    }
  },

  // Success Stories
  async getSuccessStories() {
    const { data, error } = await supabase
      .from(TABLES.SUCCESS_STORIES)
      .select('*')
      .order('date', { ascending: false });
    
    if (error) throw error;
    return data || [];
  },

  // Gamification
  async getGamificationProfile(userId: string) {
    const { data, error } = await supabase
      .from(TABLES.GAMIFICATION_PROFILES)
      .select('*')
      .eq('user_id', userId)
      .single();
    
    if (error && error.code !== 'PGRST116') throw error;
    return data;
  },

  async getAchievements() {
     const { data, error } = await supabase
      .from(TABLES.ACHIEVEMENTS)
      .select('*');
    if (error) throw error;
    return data || [];
  },
  
  async getUserAchievements(userId: string) {
     const { data, error } = await supabase
      .from(TABLES.USER_ACHIEVEMENTS)
      .select('*, achievement:app_f226d1f8f5_achievements(*)') // Note: using table name or alias if set up, but supabase-js usually uses table name. 
      // Actually, let's just fetch user achievements and then we might need to join manually or assume the relation is set up.
      // To be safe, let's just fetch user achievements.
      .eq('user_id', userId);
      
    if (error) throw error;
    return data || [];
  },

  async getChallenges() {
    const { data, error } = await supabase
      .from(TABLES.CHALLENGES)
      .select('*');
    if (error) throw error;
    return data || [];
  },

  async getRewards() {
    const { data, error } = await supabase
      .from(TABLES.REWARDS)
      .select('*');
    if (error) throw error;
    return data || [];
  },

  async getBestPractices() {
    const { data, error } = await supabase
      .from(TABLES.BEST_PRACTICES)
      .select('*');
    if (error) throw error;
    return data || [];
  },

  async getLeaderboard() {
    const { data, error } = await supabase
      .from(TABLES.GAMIFICATION_PROFILES)
      .select('*')
      .order('points', { ascending: false })
      .limit(10);
      
    if (error) throw error;
    return data || [];
  },

  // Employee methods
  async createEmployee(employeeData) {
    const { data, error } = await supabase
      .from(TABLES.EMPLOYEES)
      .insert([{ ...employeeData, updated_at: new Date().toISOString() }])
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async updateEmployee(id, updates) {
    const { data, error } = await supabase
      .from(TABLES.EMPLOYEES)
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async deleteEmployee(id) {
    const { error } = await supabase
      .from(TABLES.EMPLOYEES)
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  }
};

// Authentication helper functions
export const getCurrentUser = async () => {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) throw error;
  return user;
};

export const signInWithEmail = async (email, password) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });
  if (error) throw error;
  return data;
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};